
import java.lang.Exception;

class ExitInstructionException extends Exception
{
    public ExitInstructionException(String message)
    {
        super(message);
    }
}
