
import java.lang.Exception;

class IOInstructionException extends Exception
{
    public IOInstructionException(String message)
    {
        super(message);
    }
}
